<?php
	$serverName = "localhost";
	$databaseName="project_db";
	$userName="root";
	$password="";
	
	$connect=mysqli_connect($serverName, $userName, $password, $databaseName);
?>