<?php
	$serverName = "sql12.freemysqlhosting.net";
	$databaseName="sql12284662";
	$userName="sql12284662";
	$password="MpUIkYQp2Y";
	
	$connect=mysqli_connect($serverName, $userName, $password, $databaseName);
?>